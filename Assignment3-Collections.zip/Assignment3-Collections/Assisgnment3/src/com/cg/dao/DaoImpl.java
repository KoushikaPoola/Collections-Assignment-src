package com.cg.dao;

import java.util.*;


import com.cg.beans.Employee;

public class DaoImpl{
	public Map<String,Employee> map;
        public DaoImpl()
	{
               map = new HashMap<String,Employee>();
        }
	

}







