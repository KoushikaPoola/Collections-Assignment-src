package com.cg.service;


public class ServiceImpl {
	
        
	public boolean validateEmpId(String empId) {
		String pattern = "^[0-9]{5}_[A-Z]{2}$";
		return empId.matches(pattern);
	}

	
	public boolean validateSalary(double sal) {
		if((sal>=20000)&&(sal<=500000)) {
			return true;
		}
		else {
			return false;
		}
	}

	
	public boolean validateName(String name) {
		return name.matches("^[A-Za-z]{3,}$");
	}

}
