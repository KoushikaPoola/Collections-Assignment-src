package com.cg.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Scanner;
import java.util.Map.Entry;

import com.cg.beans.Address;
import com.cg.beans.Department;
import com.cg.beans.Employee;
import com.cg.dao.DaoImpl;
import com.cg.service.ServiceImpl;

public class Sorting {

	public static void main(String[] args) {
		ServiceImpl service = new ServiceImpl();
                DaoImpl dao = new DaoImpl();
	        Scanner sc = new Scanner(System.in); 
		
		while(true) {
			System.out.println("Enter your choice: \n 1.Add Employee \n 2.Sort by empid"
					+ " \n 3.Sort by first name \n 4.Sort by last name\n 5.Sort by salary\n 6.Sort by address\n 7.Sort by dept"
					+ "\n 8.Exit ");
			
			switch(sc.nextInt()) {
			case 1 :
                                Employee emp=new Employee();
				Department department=new Department();
				Address address=new Address();
				System.out.println("Enter employee id : ");
				String empId = sc.next();
				if (service.ValidateEmpId(employeeid)) {
						if(!dao.map.containsKey(employeeid)) {
						emp.setEmpID(employeeid);
						break;
						}
						else {
							System.out.println("enter unique employee id");
						}
					}
					else {
						System.out.println("Provide valid employee id");
				}
				System.out.println("Enter First name : ");
				String fname = sc.next();
				if(service.validateName(fname)) {
					emp.setFirstName(fname);
				}else {
					System.out.println("Enter valid format of First Name ");
					break;
				}
				System.out.println("Enter Last Name : ");
				String lname = sc.next();
				if(service.validateName(lname)) {
					emp.setLastName(lname);
				}else {
					System.out.println("Enter valid format of Last Name ");
					break;
				}
				System.out.println("Enter salary (must be in range of 20000 to 500000) : ");
				double sal = sc.nextDouble();
				if(service.validateSalary(sal)) {
					emp.setSalary(sal);
				}else {
					System.out.println("Salary is not in valid range");
					break;
				}
				System.out.println("Enter joining date (must be 'yyyy-MM-dd' format): ");
				String joinDate =  sc.next();
				
				        department = new Department();
				        System.out.println("Enter department Id : ");
				        department.setDeptId(sc.nextInt());
				        System.out.println("Enter department name : ");
				        department.setDeptName(sc.next());
				        System.out.println("Enter location : ");
				        department.setLocation(sc.next());
				
				        emp.setDepartment(department);
			
			                System.out.println("Enter address Id : ");
				        address.setAddressId(sc.nextInt());
					System.out.println("Enter address1 : ");
					address.setAddress1(sc.next());
					System.out.println("Enter city : ");
					address.setCity(sc.next());
					System.out.println("Enter state : ");
					address.setState(sc.next());

					emp.setAddress(address);
                                        dao.map.put(emp.getEmployeeID(), emp);
				        System.out.println("employee created"+dao.map);

			                break;
				
			case 2 : 
				Set<Entry<String,Employee>>entrySet1=dao.map.entrySet();
				List<Entry<String,Employee>> list1=new ArrayList<Entry<String,Employee>>(entrySet1);
				Collections.sort(list1, new Comparator<Map.Entry<String,Employee>>() {
						
						@Override
						public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						return o1.getValue().getEmpID().compareTo(o2.getValue().getEmpID());
					}
					});
					System.out.println("sorted based on empid");
                                        for (Entry<String,Employee> entry :list1){
					System.out.println(entry.getValue().getEmpID()+"\t"+entry.getValue().getFirstName());
				};
					break;
			case 3 :
				System.out.println("Sort By First Name in ascending order :");
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

					@Override
					public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						return o1.getValue().getFirstName().compareToIgnoreCase(o2.getValue().getFirstName());
					}
				});
				System.out.println("sorted based on first name");
				 for (Entry<String,Employee> entry :list){
					System.out.println(entry.getValue().getFirstName());
				};
				break; 
			case 4 : 
				System.out.println("Sort By Employee Last Name in ascending order :");
			        Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

					@Override
					public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						return o1.getValue().getLastName().compareToIgnoreCase(o2.getValue().getLastName());
					}
				});
				System.out.println("sorted by last name");
				 for (Entry<String,Employee> entry :list){
					System.out.println(entry.getValue().getLastName());
				};
				break; 
			
			case 5 : 
				System.out.println("Sort By Salary in descending order : ");
			        Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

					@Override
					public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						if(o1.getValue().getSalary()<o2.getValue().getSalary())
								return 1;
							else if(o1.getValue().getSalary()>o2.getValue().getSalary())
								return -1;
							else
								return 0;
					}
				});
				System.out.println("sorted based on salary");
				 for (Entry<String,Employee> entry :list){
					System.out.println(entry.getValue().getSalary());
				};
				break; 
			 
			case 6 : 
				System.out.println("Sort By Address : ");
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

					@Override
					public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						return o1.getValue().getAddress().getAddressId().compareTo(o2.getValue().getAddress().getAddressId());
					}
				});
				System.out.println("sorted based on addressid");
				 for (Entry<String,Employee> entry :list){
					System.out.println(entry.getValue().getAddress());
				};
				break; 
			
			case 7 :
				/*System.out.println("Sort By Department Id in ascending order :");
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

					@Override
					public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						return o1.getValue().getDepartment().getDeptId().compareTo(o2.getValue().getDepartment().getDeptId());
					}
				});
				System.out.println("sorted based on dept id");
				 for (Entry<String,Employee> entry :list){
					System.out.println(entry.getValue().getDepartment());
				};*/
								
			        System.out.println("Sort By Department Name in ascending order :");
				Set<Entry<String,Employee>>entrySet=dao.map.entrySet();
				List<Entry<String,Employee>> list=new ArrayList<Entry<String,Employee>>(entrySet);
				Collections.sort(list, new Comparator<Map.Entry<String,Employee>>() {

					@Override
					public int compare(Map.Entry<String, Employee> o1, Map.Entry<String, Employee> o2) {
						
						return o1.getValue().getDepartment().getDeptName().compareToIgnoreCase(o2.getValue().getDepartment().getDeptName());
					}
				});
				System.out.println("sorted based on dept name");
				 for (Entry<String,Employee> entry :list){
					System.out.println(entry.getValue().getDepartment());
				};
				break; 
			case 8 : 
					System.out.println("Thank You.");break;
			}		
		}
		

	}

}
